$(document).ready(function() {  
var stickyNavTop = $('#sidebar').offset().top;  
  
var stickyNav = function(){  
var scrollTop = $(window).scrollTop();  
       
if (scrollTop > stickyNavTop) {   
    $('#sidebar').addClass('sticky');  
} else {  
    $('#sidebar').removeClass('sticky');   
}  
};  
  
stickyNav();  
  
$(window).scroll(function() {  
    stickyNav();  
});  
});  